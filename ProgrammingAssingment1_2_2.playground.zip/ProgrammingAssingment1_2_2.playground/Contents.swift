enum Direction{
    case North
    case South
    case West
    case East
}

class CoordinateVD{
    var degree: Int
    var minute: UInt
    var second: UInt
    var way: Direction
    
    init?(degree: Int = 0, minute: UInt = 0, second: UInt = 0, way: Direction = Direction.North){
        self.degree = degree
        self.minute = minute
        self.second = second
        self.way = way
        
        if (degree > 180 || -180 > degree){
            if (way == .West && way == .South){
                if (degree > 90 && -90 > degree){
                    print("Uncorrect value for latitude(\(degree))")
                    return nil
                }
            }
            print("Uncorrect value for longitude(\(degree))")
            return nil
            
        }
        if (minute > 59 || 0 > minute){
            print("Uncorrect value for minute(\(minute))")
            return nil
            
        }
        if (second > 59 || 0 > second){
            print("Uncorrect value for second(\(second))")
            return nil
            
        }
            
    }
    
    func toStringA () -> String{
        return String("\(self.degree)°\(self.minute)′\(self.second)\" \(self.way)")
    }
    
    func toStringB () -> String{
        return String("\(self.degree),\(self.minute)\(self.second)° \(self.way)")
        
    }
    
    func average (coord1: CoordinateVD) -> CoordinateVD? {
        if (self.way != coord1.way){
            return nil
        }else{
        return CoordinateVD(degree: (self.degree + coord1.degree) / 2, minute: (self.minute + coord1.minute) / 2, second: (self.second + coord1.second) / 2, way: self.way )!
        }

    }
    
    class func average_method (coord1: CoordinateVD, coord2: CoordinateVD) -> CoordinateVD? {
        if (coord2.way != coord1.way){
            return nil
        }else{
            return CoordinateVD(degree: (coord2.degree + coord1.degree) / 2, minute: (coord2.minute + coord1.minute) / 2, second: (coord2.second + coord1.second) / 2, way: coord2.way )!
        }

    }
    
}

